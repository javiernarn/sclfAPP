import React, { useEffect, useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { rememberLogin } from '../../utils/welcome';
import Tooltip from '../../Components/shared/Tooltip';
import {
    filterNameInput,
    filterPhoneInput,
    filterStudentIdInput,
    normalizeEmailInput,
    isValidPhone,
    isValidStudentId,
    isValidSchoolEmail,
    humanizeValidationErrors,
    FORMAT_HINTS,
    FORMAT_ERRORS,
} from '../../utils/validators';
import { checkAvailability } from '../../utils/availability';
import AuthShell, {
    LedgerRow,
    LedgerRowPair,
    LedgerInput,
    LedgerSelect,
    LedgerPasswordInput,
    LedgerBanner,
    LedgerButton,
    LedgerGhostButton,
    StrengthTicks,
    RequirementChecklist,
    PasswordMatchNote,
} from '../../Components/shared/AuthShell';
import {
    User,
    Mail,
    Phone,
    MapPin,
    IdCard,
    GraduationCap,
    Lock,
    Camera,
    Check,
    Info,
} from '../../Components/icons';
import { COURSE_GROUPS } from '../../config/courseGroups';

const INITIAL_FORM = {
    first_name: '',
    last_name: '',
    email: '',
    phone_number: '',
    address: '',
    gender: '',
    student_id: '',
    course: '',
    password: '',
    password_confirmation: '',
};

// Each step maps to one "folder tab" in the record card header. The rail
// copy (headline/note) doubles as the step's framing, same way a case
// file's cover sheet explains what's inside before you open it.
const STEP_META = [
    {
        key: 'basic',
        label: 'Identity',
        title: <>Let's start with <span className="accent">you</span></>,
        subtitle: 'A quick photo and your name — this is how the campus will know you.',
        railHeadline: 'Every case file starts with a name.',
        railNote: 'Your name and photo let staff match you to your reports at a glance.',
    },
    {
        key: 'contact',
        label: 'Contact',
        title: <>How can we <span className="accent">reach you</span></>,
        subtitle: 'So we can notify you the moment someone finds your item.',
        railHeadline: 'A record only works if we can reach you.',
        railNote: "Your contact details are used only for case updates — never shared outside the SCLF office.",
    },
    {
        key: 'academic',
        label: 'Academic',
        title: <>Your <span className="accent">academic</span> details</>,
        subtitle: 'Helps campus staff verify your report faster.',
        railHeadline: 'Verification, made faster.',
        railNote: 'Your student ID and course let staff confirm your record without extra back-and-forth.',
    },
    {
        key: 'security',
        label: 'Security',
        title: <>Secure your <span className="accent">account</span></>,
        subtitle: "Last entry — set a strong password and your file is complete.",
        railHeadline: 'Last entry on the form.',
        railNote: 'A strong password keeps your case history and personal details locked to you alone.',
    },
];

const TOTAL_STEPS = STEP_META.length;

export default function RegisterPage() {
    const [step, setStep] = useState(1);
    const [form, setForm] = useState(INITIAL_FORM);
    const [profileImage, setProfileImage] = useState(null); // preview data URL
    const [profileFile, setProfileFile] = useState(null); // actual File
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [fieldErrors, setFieldErrors] = useState({});
    const [checking, setChecking] = useState(false);
    const [loading, setLoading] = useState(false);
    const { register } = useAuth();
    const toast = useToast();
    const navigate = useNavigate();
    const fileInputRef = useRef(null);
    const cardTopRef = useRef(null);

    useEffect(() => {
        document.title = 'Register | SCLF - Opol Community College';
    }, []);

    useEffect(() => {
        // Jump the (rare) internal scroll back to the top of the card
        // whenever the step changes, so the new step always starts in view.
        cardTopRef.current?.scrollIntoView({ block: 'start' });
    }, [step]);

    // Guards accidental data loss: closing the tab, refreshing, or hitting
    // the browser Back button mid-registration triggers the browser's own
    // "leave site?" prompt once any field has been touched.
    const isDirty = Object.entries(form).some(([key, value]) => value !== INITIAL_FORM[key]);
    useEffect(() => {
        if (!isDirty) return;
        const handler = (e) => { e.preventDefault(); e.returnValue = ''; };
        window.addEventListener('beforeunload', handler);
        return () => window.removeEventListener('beforeunload', handler);
    }, [isDirty]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        let next = value;
        if (name === 'first_name' || name === 'last_name') next = filterNameInput(value);
        if (name === 'phone_number') next = filterPhoneInput(value);
        if (name === 'student_id') next = filterStudentIdInput(value);
        if (name === 'email') next = normalizeEmailInput(value);
        setForm((prev) => ({ ...prev, [name]: next }));
        // As soon as they change a field that was flagged (e.g. "already
        // in use"), clear that specific error — it's no longer stale once
        // the value itself has changed.
        setFieldErrors((prev) => (prev[name] ? { ...prev, [name]: undefined } : prev));
    };

    const handlePickPhoto = () => fileInputRef.current?.click();

    const handlePhotoChange = (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        if (!file.type.startsWith('image/')) {
            toast.error('Please choose an image file for your profile picture.');
            return;
        }
        if (file.size / 1024 / 1024 > 5) {
            toast.error('Profile picture must be smaller than 5MB.');
            return;
        }

        setProfileFile(file);
        setFieldErrors((prev) => (prev.profile_picture ? { ...prev, profile_picture: undefined } : prev));
        const reader = new FileReader();
        reader.onload = () => setProfileImage(reader.result);
        reader.readAsDataURL(file);
    };

    const removePhoto = () => {
        setProfileImage(null);
        setProfileFile(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    // Password requirement checks
    const hasMinLength = form.password.length >= 8;
    const hasUppercase = /[A-Z]/.test(form.password);
    const hasLowercase = /[a-z]/.test(form.password);
    const hasNumber = /[0-9]/.test(form.password);
    const isPasswordValid = hasMinLength && hasUppercase && hasLowercase && hasNumber;
    const passwordsMatch = form.password === form.password_confirmation && form.password_confirmation.length > 0;

    const goBack = () => {
        setFieldErrors({});
        setStep((s) => Math.max(1, s - 1));
    };

    const jumpTo = (target) => {
        // Only allow jumping to steps already completed — never skip ahead.
        if (target < step) {
                setFieldErrors({});
            setStep(target);
        }
    };

    // Per-step checks the browser's own HTML5 "required" validation can't
    // express — both the field SHAPE (regex format) and, critically,
    // whether it's already registered to someone else. Returns true only
    // when the step is completely clear to advance past.
    const validateStep = async () => {
        const nextFieldErrors = {};

        // The form is noValidate (so we control the messages), which also
        // switches off the browser's own "required" check — every required
        // field is therefore enforced here. Whitespace-only counts as empty.
        const isBlank = (v) => !String(v ?? '').trim();

        if (step === 1) {
            if (isBlank(form.first_name)) nextFieldErrors.first_name = 'First name is required.';
            if (isBlank(form.last_name)) nextFieldErrors.last_name = 'Last name is required.';
            if (!profileFile) {
                nextFieldErrors.profile_picture = 'Profile picture is required.';
                toast.error('Please upload a profile picture before continuing.', { title: 'Photo required' });
            }
            if (Object.keys(nextFieldErrors).length > 0) {
                setFieldErrors(nextFieldErrors);
                return false;
            }
        }

        if (step === 2) {
            if (isBlank(form.email)) nextFieldErrors.email = 'Email address is required.';
            else if (!isValidSchoolEmail(form.email)) nextFieldErrors.email = FORMAT_ERRORS.email;
            if (isBlank(form.phone_number)) nextFieldErrors.phone_number = 'Phone number is required.';
            else if (!isValidPhone(form.phone_number)) nextFieldErrors.phone_number = FORMAT_ERRORS.phone;
            if (isBlank(form.gender)) nextFieldErrors.gender = 'Please select your gender.';
            if (isBlank(form.address)) nextFieldErrors.address = 'Current address is required.';

            // Don't bother hitting the network for a field that's already
            // known to be malformed — fix the shape first.
            if (Object.keys(nextFieldErrors).length > 0) {
                setFieldErrors(nextFieldErrors);
                return false;
            }

            setChecking(true);
            const [emailAvailable, phoneAvailable] = await Promise.all([
                checkAvailability('email', form.email),
                checkAvailability('phone_number', form.phone_number),
            ]);
            setChecking(false);

            if (!emailAvailable) nextFieldErrors.email = 'This email address is already in use by another account.';
            if (!phoneAvailable) nextFieldErrors.phone_number = 'This phone number is already linked to another account.';
        }

        if (step === 3) {
            if (isBlank(form.student_id)) nextFieldErrors.student_id = 'Student ID is required.';
            else if (!isValidStudentId(form.student_id)) nextFieldErrors.student_id = FORMAT_ERRORS.studentId;
            if (isBlank(form.course)) nextFieldErrors.course = 'Please select your course.';
            if (Object.keys(nextFieldErrors).length > 0) {
                setFieldErrors(nextFieldErrors);
                return false;
            }

            setChecking(true);
            const studentIdAvailable = await checkAvailability('student_id', form.student_id);
            setChecking(false);

            if (!studentIdAvailable) nextFieldErrors.student_id = 'This student ID is already registered to another account.';
        }

        setFieldErrors(nextFieldErrors);
        if (Object.keys(nextFieldErrors).length > 0) {
            toast.error('This step has an account already using that information — please use a different value.', { title: 'Already in use' });
            return false;
        }
        return true;
    };

    // The form only ever has the CURRENT step's fields mounted, so native
    // HTML5 "required" validation naturally scopes itself to that step —
    // pressing Enter or clicking Next/Create Account both fire this the
    // same way, and only after the browser confirms the visible fields
    // are valid.
    const handleStepSubmit = async (e) => {
        e.preventDefault();

        const stepOk = await validateStep();
        if (!stepOk) return;

        if (step < TOTAL_STEPS) {
            setStep((s) => s + 1);
            return;
        }

        // Final step — extra cross-field checks the browser can't do.
        if (!form.password) {
            setFieldErrors((prev) => ({ ...prev, password: 'Password is required.' }));
            return;
        }
        if (!form.password_confirmation) {
            setFieldErrors((prev) => ({ ...prev, password_confirmation: 'Please confirm your password.' }));
            return;
        }
        if (!isPasswordValid) {
            setFieldErrors((prev) => ({ ...prev, password: 'Password does not meet the requirements below.' }));
            return;
        }
        if (!passwordsMatch) {
            setFieldErrors((prev) => ({ ...prev, password_confirmation: 'Passwords do not match.' }));
            return;
        }

        setLoading(true);
        try {
            const data = new FormData();
            Object.entries(form).forEach(([key, value]) => data.append(key, value));
            if (profileFile) data.append('profile_picture', profileFile);

            await register(data);
            // A brand-new account is by definition on its first session.
            rememberLogin(true);

            // Same trick LoginPage uses: don't toast here — there's still
            // the branded MainPage loading screen ahead before they land
            // on their dashboard. Flag it instead so DashboardShell fires
            // the "Account created" toast once they've actually arrived.
            try {
                window.sessionStorage.setItem('sclf-register-toast', '1');
            } catch (e) {
                // ignore storage errors (private mode etc.)
            }

            navigate('/', { replace: true });
        } catch (err) {
            const errors = err.response?.data?.errors;

            if (err.response?.status === 429) {
                // Laravel's own throttle message is just "Too Many
                // Attempts." with no context — build a friendlier one
                // from the Retry-After header (seconds) it always sends
                // alongside a 429, so the person knows how long to wait
                // instead of just being told to try again.
                const retryAfterSeconds = parseInt(err.response.headers?.['retry-after'], 10);
                const waitMessage = Number.isFinite(retryAfterSeconds) && retryAfterSeconds > 0
                    ? `Please wait about ${Math.ceil(retryAfterSeconds / 60)} minute${Math.ceil(retryAfterSeconds / 60) === 1 ? '' : 's'} before trying again.`
                    : 'Please wait a few minutes before trying again.';
                toast.error(waitMessage, { title: 'Too many attempts' });
            } else if (errors) {
                const messages = humanizeValidationErrors(errors);
                toast.error(messages.join('\n'), { title: 'Please check your details' });
                const perField = {};
                Object.entries(errors).forEach(([field, msgs]) => {
                    perField[field] = humanizeValidationErrors({ [field]: msgs })[0];
                });
                setFieldErrors(perField);
                // Send them back to whichever step holds the conflicting
                // field, instead of leaving them stuck on step 4.
                if (errors.first_name || errors.last_name || errors.profile_picture) setStep(1);
                else if (errors.email || errors.phone_number || errors.gender || errors.address) setStep(2);
                else if (errors.student_id || errors.course) setStep(3);
            } else {
                const message = err.response?.data?.message || 'Registration failed.';
                toast.error(message);
            }
        } finally {
            setLoading(false);
        }
    };

    const meta = STEP_META[step - 1];

    const tabs = STEP_META.map((s, idx) => {
        const n = idx + 1;
        const isDone = n < step;
        const isActive = n === step;
        return (
            <button
                type="button"
                key={s.key}
                className={`lg-folder-tab${isActive ? ' is-active' : ''}${isDone ? ' is-done' : ''}`}
                onClick={() => jumpTo(n)}
                disabled={n >= step}
                aria-current={isActive ? 'step' : undefined}
            >
                <span className="n">{isDone ? <Check size={11} strokeWidth={3} /> : String(n).padStart(2, '0')}</span>
                {s.label}
            </button>
        );
    });

    return (
        <AuthShell
            wide
            docType="NEW CASE FILE"
            caseSeed="REG"
            tabs={tabs}
            title={meta.title}
            subtitle={meta.subtitle}
            railHeadline={meta.railHeadline}
            railNote={meta.railNote}
            footer={<>Already have a record? <Link to="/login">Sign in instead</Link></>}
        >
            <div ref={cardTopRef} />

            <form onSubmit={handleStepSubmit} noValidate>
                <div key={step} className="rp-step-panel">
                    {step === 1 && (
                        <>
                            <LedgerRow index={1} label={<>Profile photo <span className="lg-required">*</span></>} icon={Camera} error={fieldErrors.profile_picture}>
                                <div className="lg-avatar-row">
                                    <div className="lg-avatar-frame" onClick={handlePickPhoto} role="button" tabIndex={0} aria-required="true">
                                        {profileImage ? (
                                            <img src={profileImage} alt="Profile preview" />
                                        ) : (
                                            <Camera size={18} strokeWidth={1.75} style={{ opacity: 0.5 }} />
                                        )}
                                    </div>
                                    <div className="lg-avatar-actions">
                                        <button type="button" className="lg-avatar-btn" onClick={handlePickPhoto}>
                                            {profileImage ? 'Change photo' : 'Upload photo'}
                                        </button>
                                        {profileImage && (
                                            <button type="button" className="lg-avatar-btn danger" onClick={removePhoto}>
                                                Remove
                                            </button>
                                        )}
                                        <span className="lg-row-hint" style={{ marginTop: 0 }}>Square image, max 5MB. Required so staff can verify you.</span>
                                    </div>
                                    <input
                                        ref={fileInputRef}
                                        type="file"
                                        accept="image/*"
                                        onChange={handlePhotoChange}
                                        required
                                        style={{ display: 'none' }}
                                    />
                                </div>
                            </LedgerRow>

                            <LedgerRowPair index={2}>
                                <div>
                                    <label className="lg-row-label"><User size={12} strokeWidth={2.5} /> First name <span className="lg-required">*</span></label>
                                    <LedgerInput
                                        id="first_name"
                                        name="first_name"
                                        value={form.first_name}
                                        onChange={handleChange}
                                        autoComplete="given-name"
                                        autoFocus
                                        aria-invalid={!!fieldErrors.first_name}
                                        required
                                        title={FORMAT_HINTS.name}
                                    />
                                    {fieldErrors.first_name && <span className="lg-row-hint lg-row-error-text">{fieldErrors.first_name}</span>}
                                </div>
                                <div>
                                    <label className="lg-row-label"><User size={12} strokeWidth={2.5} /> Last name <span className="lg-required">*</span></label>
                                    <LedgerInput
                                        id="last_name"
                                        name="last_name"
                                        value={form.last_name}
                                        onChange={handleChange}
                                        autoComplete="family-name"
                                        aria-invalid={!!fieldErrors.last_name}
                                        required
                                        title={FORMAT_HINTS.name}
                                    />
                                    {fieldErrors.last_name && <span className="lg-row-hint lg-row-error-text">{fieldErrors.last_name}</span>}
                                </div>
                            </LedgerRowPair>
                        </>
                    )}

                    {step === 2 && (
                        <>
                            <LedgerRow index={1} label={<>Email address <span className="lg-required">*</span></>} icon={Mail} hint={FORMAT_HINTS.email} error={fieldErrors.email}>
                                <LedgerInput
                                    id="email"
                                    type="email"
                                    name="email"
                                    value={form.email}
                                    onChange={handleChange}
                                    autoComplete="email"
                                    placeholder="occ.lastname.firstname@gmail.com"
                                    aria-invalid={!!fieldErrors.email}
                                    autoFocus
                                    required
                                />
                            </LedgerRow>

                            <LedgerRowPair index={2}>
                                <div>
                                    <label className="lg-row-label"><Phone size={12} strokeWidth={2.5} /> Phone number <span className="lg-required">*</span></label>
                                    <LedgerInput
                                        id="phone_number"
                                        name="phone_number"
                                        inputMode="numeric"
                                        value={form.phone_number}
                                        onChange={handleChange}
                                        autoComplete="tel"
                                        placeholder="09XXXXXXXXX"
                                        title={FORMAT_HINTS.phone}
                                        aria-invalid={!!fieldErrors.phone_number}
                                        required
                                    />
                                    {fieldErrors.phone_number && <span className="lg-row-hint lg-row-error-text">{fieldErrors.phone_number}</span>}
                                </div>
                                <div>
                                    <label className="lg-row-label">Gender <span className="lg-required">*</span></label>
                                    <div className="lg-radio-row">
                                        {[
                                            { value: 'male', label: 'Male' },
                                            { value: 'female', label: 'Female' },
                                            { value: 'other', label: 'Other' },
                                        ].map((opt) => (
                                            <label className="lg-radio" key={opt.value}>
                                                <input
                                                    type="radio"
                                                    name="gender"
                                                    value={opt.value}
                                                    checked={form.gender === opt.value}
                                                    onChange={handleChange}
                                                    required
                                                />
                                                {opt.label}
                                            </label>
                                        ))}
                                    </div>
                                    {fieldErrors.gender && <span className="lg-row-hint lg-row-error-text">{fieldErrors.gender}</span>}
                                </div>
                            </LedgerRowPair>

                            <LedgerRow index={3} label={<>Current address <span className="lg-required">*</span></>} icon={MapPin} error={fieldErrors.address}>
                                <LedgerInput
                                    id="address"
                                    name="address"
                                    value={form.address}
                                    onChange={handleChange}
                                    autoComplete="street-address"
                                    placeholder="Enter your complete address"
                                    aria-invalid={!!fieldErrors.address}
                                    required
                                />
                            </LedgerRow>
                        </>
                    )}

                    {step === 3 && (
                        <LedgerRowPair index={1}>
                            <div>
                                <label className="lg-row-label"><IdCard size={12} strokeWidth={2.5} /> Student ID <span className="lg-required">*</span></label>
                                <LedgerInput
                                    id="student_id"
                                    name="student_id"
                                    inputMode="numeric"
                                    value={form.student_id}
                                    onChange={handleChange}
                                    placeholder="2021-2-04062"
                                    title={FORMAT_HINTS.studentId}
                                    aria-invalid={!!fieldErrors.student_id}
                                    autoFocus
                                    required
                                />
                                {fieldErrors.student_id && <span className="lg-row-hint lg-row-error-text">{fieldErrors.student_id}</span>}
                            </div>
                            <div>
                                <label className="lg-row-label"><GraduationCap size={12} strokeWidth={2.5} /> Course <span className="lg-required">*</span></label>
                                <LedgerSelect id="course" name="course" value={form.course} onChange={handleChange} aria-invalid={!!fieldErrors.course} required>
                                    <option value="" disabled>Select your course</option>
                                    {COURSE_GROUPS.map((group) => (
                                        <optgroup key={group.college} label={group.college}>
                                            {group.courses.map((c) => (
                                                <option key={c} value={c}>{c}</option>
                                            ))}
                                        </optgroup>
                                    ))}
                                </LedgerSelect>
                                {fieldErrors.course && <span className="lg-row-hint lg-row-error-text">{fieldErrors.course}</span>}
                            </div>
                        </LedgerRowPair>
                    )}

                    {step === 4 && (
                        <>
                            <LedgerRow index={1} label={<>Password <span className="lg-required">*</span></>} icon={Lock} error={fieldErrors.password}>
                                <LedgerPasswordInput
                                    id="password"
                                    name="password"
                                    value={form.password}
                                    onChange={handleChange}
                                    autoComplete="new-password"
                                    show={showPassword}
                                    onToggle={() => setShowPassword((v) => !v)}
                                    aria-invalid={!!fieldErrors.password}
                                    autoFocus
                                    required
                                />
                                <StrengthTicks password={form.password} />
                            </LedgerRow>

                            <LedgerRow index={2} label={<>Confirm password <span className="lg-required">*</span></>} icon={Lock} error={fieldErrors.password_confirmation}>
                                <LedgerPasswordInput
                                    id="password_confirmation"
                                    name="password_confirmation"
                                    value={form.password_confirmation}
                                    onChange={handleChange}
                                    autoComplete="new-password"
                                    show={showConfirm}
                                    onToggle={() => setShowConfirm((v) => !v)}
                                    aria-invalid={!!fieldErrors.password_confirmation}
                                    required
                                />
                                <PasswordMatchNote password={form.password} confirm={form.password_confirmation} />
                            </LedgerRow>

                            <RequirementChecklist password={form.password} />
                        </>
                    )}
                </div>

                {/* ===== Step navigation ===== */}
                <div className="lg-actions-row" style={{ marginTop: 18 }}>
                    {step > 1 && (
                        <LedgerGhostButton onClick={goBack}>Back</LedgerGhostButton>
                    )}
                    <LedgerButton disabled={loading || checking}>
                        {checking
                            ? 'Checking…'
                            : step < TOTAL_STEPS
                                ? 'Next Entry'
                                : (loading ? 'Filing record…' : 'Create Account')}
                    </LedgerButton>
                </div>
            </form>

            <style>{`
                .rp-step-panel { width: 100%; animation: lg-rise 0.3s cubic-bezier(0.22, 1, 0.36, 1) both; }
            `}</style>
        </AuthShell>
    );
}
