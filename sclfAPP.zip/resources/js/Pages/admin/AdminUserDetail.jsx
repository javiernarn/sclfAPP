import React, { useEffect, useMemo, useState } from 'react';
import axios from '../../config/axiosConfig';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
    ArrowLeft, UserCircle, Mail, Phone, IdCard, ShieldCheck, Calendar,
    VenetianMask, MapPin, GraduationCap, LogIn, LogOut, History,
    PackageSearch, ClipboardCheck, Ban, Trash2, PackageCheck, QrCode,
    Globe, ShieldAlert, Activity,
} from '../../Components/icons';
import DashboardShell from '../../Components/shared/DashboardShell';
import ImageViewer from '../../Components/shared/ImageViewer';
import DeviceIcon from '../../Components/shared/DeviceIcon';
import { useAuth } from '../../context/AuthContext';
import { useConfirm } from '../../context/ConfirmContext';
import { parseUserAgent } from '../../utils/userAgent';

const InfoItem = ({ icon: Icon, label, value }) => (
    <div className="ds-info-item">
        <span className="ds-info-icon"><Icon size={16} /></span>
        <div className="ds-info-text">
            <div className="ds-info-label">{label}</div>
            <div className="ds-info-value">{value || '—'}</div>
        </div>
    </div>
);

const ROLE_LABELS = {
    student: 'Student',
    instructor: 'Instructor',
    security_officer: 'Security Officer',
    staff: 'Staff',
    admin: 'Admin',
};

// Only these two actions count as a "sign-in event" for the Login /
// Logout History list below — every other audit action (account edits,
// item reports, claims, etc.) belongs to the account's general activity
// trail instead, which the admin can always see in full via the "Open
// full Audit Log" link at the bottom of that list.
const AUTH_ACTIONS = new Set(['auth.login', 'auth.logout']);

export default function AdminUserDetail() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { user: currentUser } = useAuth();

    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const [logs, setLogs] = useState([]);
    const [logsLoading, setLogsLoading] = useState(true);
    const [logFilter, setLogFilter] = useState('auth'); // 'auth' | 'all'

    const [cleaningClaims, setCleaningClaims] = useState(false);
    const [cleanupMessage, setCleanupMessage] = useState('');
    const confirm = useConfirm();

    const [activitySummary, setActivitySummary] = useState(null);
    const [activityLoading, setActivityLoading] = useState(true);

    useEffect(() => {
        document.title = "User Details | SCLF - Opol Community College";
    }, []);

    const loadUser = () => {
        setLoading(true);
        setError('');
        return axios.get(`/admin/users/${id}`)
            .then((res) => setUser(res.data.data))
            .catch((err) => setError(err?.response?.data?.message || 'Could not load this account.'))
            .finally(() => setLoading(false));
    };

    useEffect(() => {
        loadUser();
    }, [id]);

    const deleteCancelledClaims = async () => {
        const count = user?.cancelled_claims_count ?? 0;
        if (count === 0) return;
        const ok = await confirm({
            title: 'Delete cancelled claims?',
            message: `Permanently delete ${count} cancelled claim(s) for ${user.name}? Their related notifications will be removed too. This cannot be undone.`,
            confirmLabel: 'Delete claims',
            tone: 'danger',
        });
        if (!ok) return;

        setCleaningClaims(true);
        setCleanupMessage('');
        try {
            const res = await axios.delete(`/admin/users/${id}/claims/cancelled`);
            setCleanupMessage(res.data.message || 'Done.');
            await loadUser();
        } catch (err) {
            setCleanupMessage(err?.response?.data?.message || 'Could not delete cancelled claims.');
        } finally {
            setCleaningClaims(false);
        }
    };

    useEffect(() => {
        setLogsLoading(true);
        axios.get('/audit-logs', { params: { user_id: id } })
            .then((res) => setLogs(res.data.data || []))
            .finally(() => setLogsLoading(false));
    }, [id]);

    useEffect(() => {
        setActivityLoading(true);
        axios.get(`/admin/activity/users/${id}/summary`, { params: { days: 30 } })
            .then((res) => setActivitySummary(res.data.data))
            .catch(() => setActivitySummary(null))
            .finally(() => setActivityLoading(false));
    }, [id]);

    const authLogs = useMemo(() => logs.filter((l) => AUTH_ACTIONS.has(l.action)), [logs]);
    const visibleLogs = logFilter === 'auth' ? authLogs : logs;

    const isSelf = currentUser?.id === Number(id);
    const roleName = (user?.roles || [])[0]?.name;
    // Counter check-ins / releases are logged by whoever is staffing the
    // counter — in practice security officers, but admins can act as one
    // too — so the "Counter Duty" section only makes sense for those two
    // roles. Every role can be on the *receiving* end of a counter
    // check-in though (a student or instructor whose item was handed
    // straight to an officer), so "Claims from Counter" always shows.
    const isCounterStaff = roleName === 'security_officer' || roleName === 'admin';
    const initials = (user?.name || '?')
        .split(' ').filter(Boolean).slice(0, 2)
        .map((p) => p[0]?.toUpperCase()).join('');

    if (loading) {
        return (
            <DashboardShell eyebrow="Admin" title="User Details">
                <div className="ds-card"><div className="ds-skeleton" /><div className="ds-skeleton" /></div>
            </DashboardShell>
        );
    }

    if (!user) {
        return (
            <DashboardShell eyebrow="Admin" title="User Details">
                <div className="ds-card"><div className="ds-error">{error || 'Account not found.'}</div></div>
            </DashboardShell>
        );
    }

    return (
        <DashboardShell
            eyebrow="Admin"
            title={user.name}
            subtitle="Full profile details and sign-in history — visible to admins only."
            actions={
                <span className="ds-badge ds-badge-default">
                    {ROLE_LABELS[roleName] || 'No role'}
                </span>
            }
        >
            <Link to="/app/admin/users" className="ds-back-link">
                <ArrowLeft size={14} /> Back to Users
            </Link>

            <div className="ds-card">
                <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap', marginBottom: 6 }}>
                    {user.profile_picture_url ? (
                        <ImageViewer
                            src={user.profile_picture_url}
                            alt={user.name}
                            className="ds-avatar"
                            style={{ width: 72, height: 72, borderRadius: 20 }}
                        />
                    ) : (
                        <span className="ds-avatar" style={{ width: 72, height: 72, fontSize: 24, borderRadius: 20 }}>
                            {initials || <UserCircle size={30} />}
                        </span>
                    )}
                    <div style={{ minWidth: 0 }}>
                        <p className="ds-item-hero-name" style={{ fontSize: 19, display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                            {user.name}
                            {isSelf && <span className="ds-badge ds-badge-default">You</span>}
                            {!user.is_active && (
                                <span className="ds-badge ds-badge-rejected">
                                    <Ban size={12} style={{ verticalAlign: -2, marginRight: 3 }} /> Disabled
                                </span>
                            )}
                            {user.deleted_at && <span className="ds-badge ds-badge-default">Archived</span>}
                        </p>
                        <p className="ds-item-hero-meta">{user.email}</p>
                    </div>
                </div>

                <div className="ds-info-grid" style={{ marginTop: 14 }}>
                    <InfoItem icon={Mail} label="Email" value={user.email} />
                    <InfoItem icon={Phone} label="Phone" value={user.phone_number} />
                    <InfoItem icon={IdCard} label="ID Number" value={user.display_id} />
                    <InfoItem icon={ShieldCheck} label="Role" value={ROLE_LABELS[roleName] || 'No role'} />
                    <InfoItem icon={VenetianMask} label="Gender" value={
                        user.gender ? user.gender.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase()) : null
                    } />
                    {user.course && <InfoItem icon={GraduationCap} label="Course" value={user.course} />}
                    {user.address && <InfoItem icon={MapPin} label="Address" value={user.address} />}
                    <InfoItem
                        icon={Calendar}
                        label="Account Created"
                        value={user.created_at ? new Date(user.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : null}
                    />
                </div>
            </div>

            <div className="ds-card">
                <div className="ds-card-title">Activity</div>
                <p className="ds-card-desc">
                    What this account has reported and claimed through the app itself — a counter
                    check-in skips both of these, since the officer logs the item and the owner
                    never has to file anything, so that activity is broken out separately below.
                </p>
                <div className="ds-info-grid">
                    <InfoItem icon={PackageSearch} label="Lost Items Reported" value={user.lost_items_count ?? 0} />
                    <InfoItem icon={PackageSearch} label="Found Items Reported" value={user.found_items_count ?? 0} />
                    <InfoItem icon={ClipboardCheck} label="Claims Filed" value={user.claims_count ?? 0} />
                    <InfoItem icon={QrCode} label="Claims from Counter" value={user.counter_claims_count ?? 0} />
                    <InfoItem icon={Ban} label="Cancelled Claims" value={user.cancelled_claims_count ?? 0} />
                </div>

                {(user.cancelled_claims_count ?? 0) > 0 && (
                    <div style={{
                        marginTop: 14, display: 'flex', alignItems: 'center',
                        justifyContent: 'space-between', flexWrap: 'wrap', gap: 10,
                    }}>
                        <p className="ds-card-desc" style={{ margin: 0 }}>
                            This account has {user.cancelled_claims_count} cancelled claim(s) cluttering its history.
                        </p>
                        <button
                            type="button"
                            className="ds-btn ds-btn-danger"
                            onClick={deleteCancelledClaims}
                            disabled={cleaningClaims}
                        >
                            <Trash2 size={14} style={{ verticalAlign: -2, marginRight: 6 }} />
                            {cleaningClaims ? 'Deleting…' : 'Delete cancelled claims'}
                        </button>
                    </div>
                )}
                {cleanupMessage && <p className="ds-card-desc" style={{ marginTop: 8 }}>{cleanupMessage}</p>}
            </div>

            {isCounterStaff && (
                <div className="ds-card">
                    <div className="ds-card-title">Counter Duty</div>
                    <p className="ds-card-desc">
                        Work this officer has personally done at the Main Security Counter — items
                        checked in for a known owner (CounterIntakeService), and items physically
                        handed over to a claimant, by QR scan or manual override, from either the
                        counter or the full online report pipeline.
                    </p>
                    <div className="ds-info-grid">
                        <InfoItem icon={PackageCheck} label="Items Checked In at Counter" value={user.counter_checkins_count ?? 0} />
                        <InfoItem icon={QrCode} label="Items Released" value={user.items_released_count ?? 0} />
                    </div>
                </div>
            )}

            <div className="ds-card">
                <div className="ds-card-title-icon" style={{ fontSize: 15.5, fontWeight: 800 }}>
                    <Activity size={17} /> Devices &amp; IP Addresses
                </div>
                <p className="ds-card-desc">
                    Every device and IP address this account has been seen on in the last 30 days,
                    from the raw request log (separate from sign-in events above). A flagged count
                    here means some of that traffic tripped the automatic spam/abuse thresholds —
                    see <Link to="/app/admin/activity">User Activity</Link> for the full, filterable feed.
                </p>

                {activityLoading && <div className="ds-skeleton" />}

                {!activityLoading && !activitySummary && (
                    <div className="ds-empty">No request activity recorded for this account yet.</div>
                )}

                {!activityLoading && activitySummary && (
                    <>
                        <div className="ds-info-grid">
                            <InfoItem icon={Activity} label="Requests (30 days)" value={activitySummary.total_requests} />
                            <InfoItem icon={Globe} label="Distinct IP Addresses" value={activitySummary.distinct_ip_count} />
                            <InfoItem icon={UserCircle} label="Distinct Devices" value={activitySummary.distinct_device_count} />
                            <InfoItem
                                icon={ShieldAlert}
                                label="Flagged Requests"
                                value={activitySummary.flagged_requests > 0
                                    ? <span style={{ color: '#dc2626', fontWeight: 700 }}>{activitySummary.flagged_requests}</span>
                                    : 0}
                            />
                        </div>

                        {activitySummary.ip_addresses?.length > 0 && (
                            <div style={{ marginTop: 14 }}>
                                <p className="ds-list-item-meta" style={{ marginBottom: 6, fontWeight: 700 }}>IP addresses used</p>
                                <div className="ds-chip-row">
                                    {activitySummary.ip_addresses.map((ip) => (
                                        <span key={ip.ip_address} className="ds-badge ds-badge-default ds-badge-icon" title={`Last seen ${new Date(ip.last_seen).toLocaleString()}`}>
                                            <Globe size={12} /> {ip.ip_address} · {ip.hits}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        )}

                        {activitySummary.devices?.length > 0 && (
                            <div style={{ marginTop: 14 }}>
                                <p className="ds-list-item-meta" style={{ marginBottom: 6, fontWeight: 700 }}>Devices used</p>
                                <div className="ds-chip-row">
                                    {activitySummary.devices.map((d, idx) => (
                                        <span key={idx} className="ds-badge ds-badge-default ds-badge-icon" title={`Last seen ${new Date(d.last_seen).toLocaleString()}`}>
                                            <DeviceIcon deviceType={d.device_type} size={12} />
                                            {[d.platform, d.browser].filter(Boolean).join(' · ') || 'Unknown'} · {d.hits}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        )}
                    </>
                )}
            </div>

            <div className="ds-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
                    <div className="ds-card-title-icon" style={{ fontSize: 15.5, fontWeight: 800 }}>
                        <History size={17} /> Login / Logout History
                    </div>
                    <div className="ds-seg" role="tablist" aria-label="Filter activity log">
                        <button
                            type="button"
                            className={`ds-seg-btn ${logFilter === 'auth' ? 'active' : ''}`}
                            onClick={() => setLogFilter('auth')}
                        >
                            Sign-ins only
                        </button>
                        <button
                            type="button"
                            className={`ds-seg-btn ${logFilter === 'all' ? 'active' : ''}`}
                            onClick={() => setLogFilter('all')}
                        >
                            All activity
                        </button>
                    </div>
                </div>
                <p className="ds-card-desc">
                    Every time this account has logged in or out, most recent first.
                </p>

                {logsLoading && <div className="ds-skeleton" />}
                {!logsLoading && visibleLogs.length === 0 && (
                    <div className="ds-empty">No {logFilter === 'auth' ? 'sign-in' : 'activity'} entries yet.</div>
                )}
                {!logsLoading && visibleLogs.length > 0 && (
                    <ul className="ds-list">
                        {visibleLogs.map((l) => {
                            const ua = parseUserAgent(l.user_agent);
                            return (
                            <li key={l.id} className="ds-list-item">
                                <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
                                    <span className="ds-thumb" style={{ width: 34, height: 34, flexShrink: 0 }}>
                                        {l.action === 'auth.login' ? <LogIn size={16} />
                                            : l.action === 'auth.logout' ? <LogOut size={16} />
                                                : <History size={16} />}
                                    </span>
                                    <div style={{ minWidth: 0 }}>
                                        <p className="ds-list-item-title">
                                            {l.action === 'auth.login' ? 'Logged in'
                                                : l.action === 'auth.logout' ? 'Logged out'
                                                    : l.action}
                                        </p>
                                        <p className="ds-list-item-meta">{l.description}</p>
                                        {(l.ip_address || l.user_agent) && (
                                            <p className="ds-list-item-meta" style={{ display: 'inline-flex', alignItems: 'center', gap: 10, marginTop: 2 }}>
                                                {l.user_agent && (
                                                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                                                        <DeviceIcon deviceType={ua.deviceType} size={12} /> {ua.label}
                                                    </span>
                                                )}
                                                {l.ip_address && (
                                                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                                                        <Globe size={12} /> {l.ip_address}
                                                    </span>
                                                )}
                                            </p>
                                        )}
                                    </div>
                                </div>
                                <span className="ds-list-item-meta">{new Date(l.created_at).toLocaleString()}</span>
                            </li>
                            );
                        })}
                    </ul>
                )}

                <Link to="/app/admin/audit-log" className="ds-back-link" style={{ marginTop: 12, marginBottom: 0 }}>
                    Open full Audit Log <ArrowLeft size={14} style={{ transform: 'rotate(180deg)' }} />
                </Link>
            </div>
        </DashboardShell>
    );
}