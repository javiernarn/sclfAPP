import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useAppTheme } from "../../hooks/useAppTheme";
import logo from "../../assets/images/site-logo.png";
import AccountMenu from "./AccountMenu";
import Tooltip from "./Tooltip";
import HelpHints from "./HelpHints";
import "./DashboardShell.css";
import {
    LayoutDashboard,
    PackageSearch,
    Megaphone,
    PanelLeftClose,
    PanelLeftOpen,
    X,
    LogOut,
    ChevronDown,
    ChevronUp,
    UserCircle,
    Palette,
    Check,
    ClipboardCheck,
    Bell,
    Boxes,
    QrCode,
    ShieldCheck,
} from "lucide-react";

// The five themes offered from the account menu's "Theme" picker. 'white'
// (Default) and 'black' (Dark) are plain — the same two the public login
// page toggles between. 'maroon' / 'blue' / 'yellow' are light, color-
// tinted themes matching each program's color (maroon for BSIT, blue for
// BEED/BSED, yellow for BSBA) — students aren't locked to their program's
// color, it's just offered as an option alongside the two plain modes.
const THEME_OPTIONS = [
    { key: "white", label: "Default" },
    { key: "black", label: "Dark" },
    { key: "blue", label: "Blue" },
    { key: "yellow", label: "Yellow" },
    { key: "maroon", label: "Maroon" },
];
const themeLabel = (key) => THEME_OPTIONS.find((t) => t.key === key)?.label || "Default";

// Shared "Theme" row + its "Choose Theme" flyout, used inside both the
// header and sidebar account menus. Picking an option no longer closes
// anything — it deliberately leaves both the popover and the parent
// account menu open, so the person can click through a few themes to
// compare them without the panel disappearing after the first pick.
//
// `side` (horizontal) and `align` (vertical) are independent:
//   - `side`: "left" opens toward the left, "right" opens toward the
//     right — pick whichever side actually has open screen space.
//   - `align`: "bottom" shares the account menu box's bottom edge
//     ("same ground"), "top" shares its top edge — matches whichever
//     way that particular account menu itself grows (sidebar menu grows
//     upward off the trigger, so its flyout is bottom-aligned; header
//     menu drops down, so its flyout is top-aligned).
const ThemePicker = ({ open, onToggle, current, onPick, side = "right", align = "top" }) => (
    <div className="ds-theme-row-wrap">
        <button
            type="button"
            className="ds-menu-item"
            onClick={onToggle}
            role="menuitem"
            aria-haspopup="true"
            aria-expanded={open}
        >
            <Palette size={16} />
            Theme
            <span className="ds-theme-pill">{themeLabel(current)}</span>
        </button>
        {open && (
            <div
                className={`ds-theme-popover ds-theme-popover-side-${side} ds-theme-popover-align-${align}`}
                role="menu"
            >
                <div className="ds-theme-popover-title">Choose Theme</div>
                {THEME_OPTIONS.map((t) => (
                    <button
                        key={t.key}
                        type="button"
                        className="ds-theme-option"
                        onClick={() => onPick(t.key)}
                        role="menuitemradio"
                        aria-checked={current === t.key}
                    >
                        <span className={`ds-theme-swatch ds-theme-swatch-${t.key}`} />
                        {t.label}
                        {current === t.key && <Check size={15} className="ds-theme-check" />}
                    </button>
                ))}
            </div>
        )}
    </div>
);

// Nav model per role. Each item now carries a lucide-react icon component
// instead of an emoji, so the sidebar reads as a real product UI.
const NAV_BY_ROLE = {
    student: [
        { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, end: true },
        { to: "/lost-items", label: "Lost Items", icon: PackageSearch },
        { to: "/lost-items/create", label: "Report Lost Item", icon: Megaphone },
        { to: "/found-items", label: "Found Items", icon: PackageSearch },
        { to: "/found-items/create", label: "Report Found Item", icon: Megaphone },
        { to: "/claims", label: "My Claims", icon: ClipboardCheck },
        { to: "/notifications", label: "Notifications", icon: Bell },
    ],
    security_officer: [
        { to: "/security/dashboard", label: "Dashboard", icon: LayoutDashboard, end: true },
        { to: "/security/found-items", label: "Found Item Reviews", icon: PackageSearch },
        { to: "/security/claims", label: "Claims", icon: ClipboardCheck },
        { to: "/security/inventory", label: "Inventory", icon: Boxes },
        { to: "/security/qr-scanner", label: "QR Release Scanner", icon: QrCode },
        { to: "/notifications", label: "Notifications", icon: Bell },
    ],
    admin: [
        { to: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard, end: true },
        { to: "/lost-items", label: "Lost Items", icon: PackageSearch },
        { to: "/found-items", label: "Found Items", icon: PackageSearch },
        { to: "/claims", label: "Claims", icon: ClipboardCheck },
        { to: "/admin/users", label: "Users", icon: UserCircle },
        { to: "/admin/audit-log", label: "Audit Log", icon: ShieldCheck },
        { to: "/notifications", label: "Notifications", icon: Bell },
    ],
};

const COLLAPSE_KEY = "sclf-sidebar-collapsed";
const DESKTOP_QUERY = "(min-width: 960px)";

// Shared branded shell for every "logged in" screen (student + admin).
// Layout model: sidebar + header are pinned in place (never move); only
// the main content pane scrolls. Sidebar is fully visible on its own —
// no internal scrollbar — and can collapse to icons-only on desktop via
// the header burger, or slide over as an overlay on mobile.
const DashboardShell = ({ title, subtitle, eyebrow, actions, children }) => {
    const { user, roles, logout } = useAuth();
    const { theme, setTheme } = useAppTheme();
    const isDark = theme === "black";
    const navigate = useNavigate();
    const location = useLocation();

    const [menuOpen, setMenuOpen] = useState(false);
    const [sidebarMenuOpen, setSidebarMenuOpen] = useState(false);
    const [themePickerOpen, setThemePickerOpen] = useState(false);
    const [sidebarThemePickerOpen, setSidebarThemePickerOpen] = useState(false);
    const [sidebarOpen, setSidebarOpen] = useState(false); // mobile overlay
    const [collapsed, setCollapsed] = useState(() => {
        if (typeof window === "undefined") return false;
        return window.localStorage.getItem(COLLAPSE_KEY) === "1";
    });
    // Tracks the same breakpoint that turns the sidebar from a persistent
    // column into a slide-over overlay. The sidebar's own account menu uses
    // this to switch how it positions itself: on desktop it's a flyout
    // pinned to the sidebar's right edge (plenty of room beside it); on
    // mobile/tablet, where the screen is nowhere near as wide, that same
    // flyout math pushes the panel almost off the right edge of the phone.
    // Below the breakpoint it instead anchors to the trigger button's own
    // left edge and grows upward — the same "pop up near the control that
    // opened it" behavior the header's account menu already has. See the
    // AccountMenu placement prop further down.
    const [isDesktop, setIsDesktop] = useState(() => {
        if (typeof window === "undefined") return true;
        return window.matchMedia(DESKTOP_QUERY).matches;
    });

    // Top-of-header route progress bar. "idle" | "is-active" | "is-done".
    // Fires on every route change — a sidebar nav click, the account menu's
    // Profile link, logging out, anything that changes location.pathname —
    // by watching the router's own location, so it doesn't need every page
    // to individually report when it's "done"; it just plays a short,
    // NProgress-style sweep across the top edge of the header on navigation.
    const [routeProgress, setRouteProgress] = useState("idle");
    const isFirstRoute = useRef(true);
    useEffect(() => {
        if (isFirstRoute.current) {
            // Don't play it on first mount/initial page load — only on
            // subsequent in-app navigations.
            isFirstRoute.current = false;
            return;
        }
        setRouteProgress("is-active");
        const toDone = setTimeout(() => setRouteProgress("is-done"), 380);
        const toIdle = setTimeout(() => setRouteProgress("idle"), 700);
        return () => {
            clearTimeout(toDone);
            clearTimeout(toIdle);
        };
    }, [location.pathname]);

    // Trigger-button refs (used by AccountMenu to compute where the portal
    // menu should be positioned) and menu refs (the portal's own root node)
    // — both are checked on outside-click since the menus themselves now
    // render outside their trigger's DOM subtree, in a portal.
    const menuTriggerRef = useRef(null);
    const menuRef = useRef(null);
    const sidebarMenuTriggerRef = useRef(null);
    const sidebarMenuRef = useRef(null);
    // Ref to the sidebar <nav> itself — the sidebar account menu flies out
    // from this element's right edge (see placement="top-after" below),
    // rather than from wherever the trigger button sits, so it lands in the
    // same spot whether the sidebar is collapsed or expanded.
    const sidebarRef = useRef(null);

    const isAdmin = Array.isArray(roles) && roles.includes("admin");
    const isSecurity = Array.isArray(roles) && roles.includes("security_officer");
    const navRole = isAdmin ? "admin" : isSecurity ? "security_officer" : "student";
    const navItems = NAV_BY_ROLE[navRole];
    const homePath = isAdmin ? "/admin/dashboard" : isSecurity ? "/security/dashboard" : "/dashboard";
    const navLabel = isAdmin ? "Admin" : isSecurity ? "Security Officer" : "Student / Faculty";

    const handleLogout = async () => {
        try {
            await logout();
        } finally {
            navigate("/login", { replace: true });
        }
    };

    const isActive = (item) =>
        item.end ? location.pathname === item.to : location.pathname.startsWith(item.to);

    const initials = (user?.name || "?")
        .split(" ")
        .filter(Boolean)
        .slice(0, 2)
        .map((p) => p[0]?.toUpperCase())
        .join("");

    // When the logged-in account has an uploaded profile picture, the
    // avatar bubble in both the sidebar (bottom-left) and the header
    // (top-right) shows that photo instead of the initials fallback —
    // same treatment the Profile page itself already uses.
    const avatarStyle = user?.profile_picture_url
        ? {
              backgroundImage: `url(${user.profile_picture_url})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
          }
        : undefined;
    const avatarContent = user?.profile_picture_url ? null : initials || "U";

    // Single burger button drives two different behaviours depending on
    // viewport: collapse the persistent sidebar on desktop, or open/close
    // the slide-over overlay on mobile.
    const handleBurgerClick = () => {
        if (isDesktop) {
            setCollapsed((v) => {
                const next = !v;
                try {
                    window.localStorage.setItem(COLLAPSE_KEY, next ? "1" : "0");
                } catch (e) {
                    // ignore storage errors (private mode etc.)
                }
                return next;
            });
        } else {
            setSidebarOpen((v) => !v);
        }
    };

    // Close the account dropdown on outside click / Escape instead of the
    // previous onMouseLeave (which closed the menu the instant the mouse
    // drifted off it, before a click could register).
    useEffect(() => {
        if (!menuOpen) {
            setThemePickerOpen(false);
            return;
        }
        const onClick = (e) => {
            if (menuTriggerRef.current?.contains(e.target)) return;
            if (menuRef.current?.contains(e.target)) return;
            setMenuOpen(false);
        };
        const onKey = (e) => {
            if (e.key === "Escape") setMenuOpen(false);
        };
        document.addEventListener("mousedown", onClick);
        document.addEventListener("keydown", onKey);
        return () => {
            document.removeEventListener("mousedown", onClick);
            document.removeEventListener("keydown", onKey);
        };
    }, [menuOpen]);

    // Same pattern for the sidebar's own account dropdown (bottom-left).
    useEffect(() => {
        if (!sidebarMenuOpen) {
            setSidebarThemePickerOpen(false);
            return;
        }
        const onClick = (e) => {
            if (sidebarMenuTriggerRef.current?.contains(e.target)) return;
            if (sidebarMenuRef.current?.contains(e.target)) return;
            setSidebarMenuOpen(false);
        };
        const onKey = (e) => {
            if (e.key === "Escape") setSidebarMenuOpen(false);
        };
        document.addEventListener("mousedown", onClick);
        document.addEventListener("keydown", onKey);
        return () => {
            document.removeEventListener("mousedown", onClick);
            document.removeEventListener("keydown", onKey);
        };
    }, [sidebarMenuOpen]);

    // Close the mobile overlay automatically if the viewport grows past
    // the desktop breakpoint while it's open.
    useEffect(() => {
        const mq = window.matchMedia(DESKTOP_QUERY);
        const onChange = (e) => {
            setIsDesktop(e.matches);
            if (e.matches) setSidebarOpen(false);
        };
        mq.addEventListener("change", onChange);
        return () => mq.removeEventListener("change", onChange);
    }, []);

    return (
        <div className={`ds-shell ds-layout ${theme} ${isDark ? "dark" : "light"}`}>
                {sidebarOpen && (
                    <div className="ds-sidebar-backdrop" onClick={() => setSidebarOpen(false)} />
                )}

                <nav ref={sidebarRef} className={`ds-sidebar ${sidebarOpen ? "open" : ""} ${collapsed ? "collapsed" : ""}`}>
                    <Link
                        to={homePath}
                        className="ds-brand"
                        onClick={() => setSidebarOpen(false)}
                    >
                        <img src={logo} alt="SCLF Logo" />
                        <span className="ds-brand-text">
                            <span className="ds-brand-name">SCLF</span>
                            <span className="ds-brand-sub">Opol Community College</span>
                        </span>
                    </Link>

                    <div className="ds-nav-label">{navLabel}</div>
                    <ul className="ds-nav">
                        {navItems.map((item) => {
                            const Icon = item.icon;
                            const link = (
                                <Link
                                    to={item.to}
                                    className={`ds-nav-link ${isActive(item) ? "active" : ""}`}
                                    onClick={() => setSidebarOpen(false)}
                                >
                                    <span className="ds-nav-icon">
                                        <Icon size={18} strokeWidth={2} />
                                    </span>
                                    <span className="ds-nav-text">{item.label}</span>
                                </Link>
                            );
                            return (
                                <li key={item.to}>
                                    {collapsed ? <Tooltip label={item.label} side="right">{link}</Tooltip> : link}
                                </li>
                            );
                        })}
                    </ul>

                    <div className="ds-sidebar-spacer" />

                    {/* Single Account control pinned at the very bottom of the
                        sidebar. Opens a menu (Profile / theme / log out) via
                        AccountMenu, which portals it into <body> and
                        positions it from the trigger's real on-screen
                        position — never clipped by the sidebar's own
                        `overflow: hidden`.
                        - Desktop (>=960px): a flyout pinned to the sidebar's
                          own right edge, so it lands in the same spot
                          whether the sidebar is collapsed or expanded.
                        - Mobile/tablet (<960px): there isn't room beside a
                          250px-wide sidebar on a phone-width screen, so it
                          instead anchors to the trigger button's own left
                          edge and grows upward — the same "pop up near the
                          control that opened it" behavior as the header's
                          account menu, instead of a flyout that gets
                          clamped hard against the screen's right edge. */}
                    <div className="ds-sidebar-footer">
                        <div className="ds-sidebar-menu-wrap">
                            <AccountMenu
                                open={sidebarMenuOpen}
                                onClose={() => setSidebarMenuOpen(false)}
                                triggerRef={sidebarMenuTriggerRef}
                                alignRef={isDesktop ? sidebarRef : undefined}
                                menuRef={sidebarMenuRef}
                                placement={isDesktop ? "level-after" : "level-start"}
                                offset={12}
                                width={260}
                                theme={isDark ? "dark" : "light"}
                                className="ds-menu ds-sidebar-menu"
                            >
                                <div className="ds-menu-name">{user?.name || "Account"}</div>
                                <div className="ds-menu-email">{user?.email || ""}</div>
                                <div className="ds-menu-divider" />
                                <Link
                                    to="/profile"
                                    className="ds-menu-item"
                                    onClick={() => setSidebarMenuOpen(false)}
                                    role="menuitem"
                                >
                                    <UserCircle size={16} /> Profile
                                </Link>
                                <ThemePicker
                                    open={sidebarThemePickerOpen}
                                    onToggle={() => setSidebarThemePickerOpen((v) => !v)}
                                    current={theme}
                                    onPick={(key) => setTheme(key)}
                                    side="right"
                                    align="bottom"
                                />
                                <div className="ds-menu-divider" />
                                <button
                                    type="button"
                                    className="ds-menu-item danger"
                                    onClick={handleLogout}
                                    role="menuitem"
                                >
                                    <LogOut size={16} /> Log out
                                </button>
                            </AccountMenu>

                            <button
                                type="button"
                                ref={sidebarMenuTriggerRef}
                                className="ds-user-row ds-user-row-btn"
                                onClick={() => setSidebarMenuOpen((v) => !v)}
                                aria-label="Account menu"
                                aria-expanded={sidebarMenuOpen}
                                aria-haspopup="true"
                                title={collapsed ? user?.name || "Account" : undefined}
                            >
                                <span className="ds-avatar" style={avatarStyle}>{avatarContent}</span>
                                <div className="ds-user-text" style={{ minWidth: 0 }}>
                                    <div className="ds-user-name">{user?.name || "Account"}</div>
                                    <div className="ds-user-email">{user?.email || ""}</div>
                                </div>
                                <ChevronUp size={15} className="ds-user-row-chevron" />
                            </button>
                        </div>
                    </div>
                </nav>

                <div className="ds-content">
                    <header className="ds-topbar">
                        <div
                            className={`ds-route-progress ${routeProgress !== "idle" ? routeProgress : ""}`}
                            aria-hidden="true"
                        />
                        <div className="ds-topbar-left">
                            <Tooltip label={collapsed ? "Expand sidebar" : "Collapse sidebar"}>
                                <button
                                    type="button"
                                    className="ds-icon-btn ds-hamburger"
                                    onClick={handleBurgerClick}
                                    aria-label={collapsed ? "Expand sidebar" : "Toggle sidebar"}
                                >
                                    {sidebarOpen ? (
                                        <X size={18} />
                                    ) : collapsed ? (
                                        <PanelLeftOpen size={18} />
                                    ) : (
                                        <PanelLeftClose size={18} />
                                    )}
                                </button>
                            </Tooltip>
                            <Link to={homePath} className="ds-topbar-brand">
                                <img src={logo} alt="SCLF Logo" />
                                <span>SCLF</span>
                            </Link>
                        </div>

                        <div className="ds-topbar-actions">
                            <HelpHints roles={roles} navRole={navRole} isDark={isDark} />
                            <div className="ds-menu-wrap">
                                <button
                                    type="button"
                                    ref={menuTriggerRef}
                                    className="ds-profile-btn"
                                    onClick={() => setMenuOpen((v) => !v)}
                                    aria-label="Account menu"
                                    aria-expanded={menuOpen}
                                    aria-haspopup="true"
                                >
                                    <span className="ds-avatar" style={avatarStyle}>{avatarContent}</span>
                                    <span className="ds-profile-btn-name">{user?.name || "Account"}</span>
                                    <ChevronDown size={16} className="ds-profile-chevron" />
                                </button>

                                <AccountMenu
                                    open={menuOpen}
                                    onClose={() => setMenuOpen(false)}
                                    triggerRef={menuTriggerRef}
                                    menuRef={menuRef}
                                    placement="bottom-end"
                                    width={220}
                                    theme={isDark ? "dark" : "light"}
                                    className="ds-menu"
                                >
                                    <div className="ds-menu-name">{user?.name || "Account"}</div>
                                    <div className="ds-menu-email">{user?.email || ""}</div>
                                    <div className="ds-menu-divider" />
                                    <Link
                                        to="/profile"
                                        className="ds-menu-item"
                                        onClick={() => setMenuOpen(false)}
                                        role="menuitem"
                                    >
                                        <UserCircle size={16} /> Profile
                                    </Link>
                                    <ThemePicker
                                        open={themePickerOpen}
                                        onToggle={() => setThemePickerOpen((v) => !v)}
                                        current={theme}
                                        onPick={(key) => setTheme(key)}
                                        side="left"
                                        align="top"
                                    />
                                    <div className="ds-menu-divider" />
                                    <button
                                        type="button"
                                        className="ds-menu-item danger"
                                        onClick={handleLogout}
                                        role="menuitem"
                                    >
                                        <LogOut size={16} /> Log out
                                    </button>
                                </AccountMenu>
                            </div>
                        </div>
                    </header>

                    <main className="ds-main">
                        {(title || actions) && (
                            <div className="ds-header">
                                <div className="ds-header-text">
                                    {eyebrow && <span className="ds-eyebrow">{eyebrow}</span>}
                                    {title && <h1 className="ds-title">{title}</h1>}
                                    {subtitle && <p className="ds-subtitle">{subtitle}</p>}
                                </div>
                                {actions && <div className="ds-actions">{actions}</div>}
                            </div>
                        )}

                        {children}
                    </main>
                </div>
            </div>
    );
};

export default DashboardShell;
