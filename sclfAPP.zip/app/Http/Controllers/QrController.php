<?php

namespace App\Http\Controllers;

use App\Models\QrRelease;
use App\Services\Release\ItemReleaseService;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class QrController extends Controller
{
    public function __construct(protected ItemReleaseService $release)
    {
    }

    public function scan(Request $request)
    {
        if (!$request->user()->hasAnyRole(['security_officer', 'admin'])) {
            abort(403, 'Only Security Officers may release items.');
        }

        // Accepts either a single scanned QR "payload" string (camera flow)
        // or the split public_code/token pair (manual-entry fallback).
        $validated = $request->validate([
            'payload' => 'nullable|string',
            'public_code' => 'nullable|string|required_without:payload',
            'token' => 'nullable|string|required_without:payload',
        ]);

        if (!empty($validated['payload'])) {
            $parsed = QrRelease::parsePayload($validated['payload']);

            if (!$parsed) {
                throw ValidationException::withMessages([
                    'qr' => ['That QR code is not a recognized SCLF release pass.'],
                ]);
            }

            [$publicCode, $token] = [$parsed['public_code'], $parsed['token']];
        } else {
            $publicCode = $validated['public_code'];
            $token = $validated['token'];
        }

        $qr = $this->release->scanAndRelease($publicCode, $token, $request->user());

        return response()->json([
            'success' => true,
            'message' => 'Item released successfully. Case closed.',
            'data' => $qr->load([
                'claim.claimant:id,name,student_id',
                'foundItem:id,item_name,category,image_path,storage_location_id',
            ]),
        ]);
    }

    public function revoke(Request $request, QrRelease $qrRelease)
    {
        if (!$request->user()->hasAnyRole(['security_officer', 'admin'])) {
            abort(403);
        }

        $qr = $this->release->revoke($qrRelease, $request->user(), $request->input('reason'));

        return response()->json(['success' => true, 'message' => 'Release code revoked.', 'data' => $qr]);
    }
}
